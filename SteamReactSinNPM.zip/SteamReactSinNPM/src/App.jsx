import MenuSuperior from "./componentes/menu"
import Tienda from "./componentes/tienda";
import ServicioInformacion from "./servicios/axios/ServicioInformacion";
import { useState,useEffect } from "react";
import {Routes, Route } from 'react-router-dom';
import Biblioteca from "./componentes/biblioteca";
import DetalleCarrito from "./componentes/detalleCarrito";
import Pagina404 from "./componentes/pagina404";
import UseStorageState from "./servicios/UseStorageState";

function App() {

  const [informacion,setInformacion] = useState([])
  const [juegosComprados,setJuegosComprados] = UseStorageState("biblioteca",[])
  const [juegosCarrito,setJuegosCarrito] = UseStorageState("carrito",[])
  
    useEffect(() => {
      ServicioInformacion.getAll()
        .then((response) => {
          setInformacion(response.data);
        })
        .catch((error) => {
          
         alert("No se ha podido descargar la informacion...")
        });
    }, []);


  return (
    <div className="App">
      <header className="App-header">
        <MenuSuperior juegosCarrito={juegosCarrito} setJuegosCarrito={setJuegosCarrito}/>
      </header>
      <main>
        <Routes>
          <Route path="*" element={<Pagina404/>}/>
          <Route path="/" element={<Tienda informacion={informacion} juegosComprados={juegosComprados} juegosCarrito={juegosCarrito} setJuegosCarrito={setJuegosCarrito}/>}/>
          <Route path="/biblioteca" element={<Biblioteca juegosComprados={juegosComprados} informacion={informacion}/>}/>
          <Route path="/detalleCarrito" element={<DetalleCarrito juegosComprados={juegosComprados} setJuegosComprados={setJuegosComprados} juegosCarrito= {juegosCarrito} setJuegosCarrito={setJuegosCarrito}/>}/>
        </Routes>
      </main>
    </div>
  )
}

export default App
