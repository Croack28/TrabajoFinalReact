import React from 'react';
import "../estilos/detalleJuego.css"; 

const DetalleJuego = ({ informacion, idJuego }) => {
  if (!informacion || !Array.isArray(informacion)) {
    return <p className="detalleJuego-error">Error: No hay información disponible.</p>;
  }

  // Buscar el juego por su ID
  const juego = informacion.find(juego => juego.id === idJuego);

  // Si no se encuentra el juego
  if (!juego) {
    return <p className="detalleJuego-error">Juego no encontrado.</p>;
  }

  return (
    <div className="detalleJuego">
      <img className="detalleJuego-img" src={juego.url} alt={juego.nombre} />
      <div className="detalleJuego-info">
        <h2 className="detalleJuego-nombre">{juego.nombre}</h2>
        <p className="detalleJuego-descripcion">{juego.descripcion}</p>
      </div>
    </div>
  );
};

export default DetalleJuego;
