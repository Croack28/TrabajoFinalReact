
import http from "./http-axios.js";

class ServicioInformacion {
   getAll() {
     return http.get("/juegos");
   }  

   getPorNombre(nombre) {
    return http.get(`/juegos?nombre=${nombre}`);
  } 

  getPorPrecio(precioMenor, precioSuperior) {
    let url = "/juegos?";
    if (precioMenor !== "") {
      url += `precio_gt=${Number(precioMenor)}`;
    }
    if (precioSuperior !== "") {
      url += `&precio_lt=${Number(precioSuperior)}`;
    }
    return http.get(url);
  }
  

  get(id) {
    return http.get(`/juegos/${id}`);
  } 

  borrarElemento(id){
    return http.delete(`/juegos/${id}`);
  }

  editarElemento(id,data){
    return http.patch(`/juegos/${id}`,data);
  }
}

export default new ServicioInformacion();
