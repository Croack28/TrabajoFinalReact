import React from "react";
import { FaTimes } from "react-icons/fa";
import "../estilos/modalConsulta.css"; // Importa el CSS específico

const ConsultarJuego = ({ juego, cerrarModalConsultar }) => {
  if (!juego) return null; // No renderiza si no hay juego

  return (
    <div className="modal-overlay-consulta">
      <div className="modal-container-consulta">
        {/* Botón para cerrar */}
        <button className="modal-close-button-consulta" onClick={cerrarModalConsultar}>
          <FaTimes size={20} />
        </button>

        {/* 📷 Imagen del juego */}
        <img src={juego.url} alt={juego.nombre} className="modal-image-consulta" />

        {/* 📌 Información del juego */}
        <div className="modal-info-consulta">
          <h2 className="modal-title-consulta">{juego.nombre}</h2>
          <p className="modal-description-consulta">{juego.descripcion}</p>

          {/* 💰 Precio */}
          <p className="m">
            <strong>Precio:</strong>
          </p>
          <p className="modal-price-consulta">
            {juego.precio ? `${juego.precio}€` : "Gratis"}
          </p>
        </div>
      </div>
    </div>
  );
};

export default ConsultarJuego;
