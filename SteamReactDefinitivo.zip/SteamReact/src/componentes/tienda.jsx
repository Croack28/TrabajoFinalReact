import React, { useState, useEffect, useRef } from "react";
import gsap from "gsap";
import "../estilos/menu.css";
import Swal from "sweetalert2";
import "../estilos/tienda.css";
import ServicioInformacion from "../servicios/axios/ServicioInformacion";

const Tienda = ({ informacion, juegosComprados, juegosCarrito, setJuegosCarrito }) => {
    const [errores, setErrores] = useState({});
    const [juegosAMostrar, setJuegosAMostrar] = useState([]);
    const juegosRef = useRef([]); // Referencia a los juegos mostrados

    useEffect(() => {
        if (informacion && informacion.length > 0) {
            setJuegosAMostrar(informacion);
        }
    }, [informacion]);

    useEffect(() => {
        if (juegosAMostrar.length > 0) {
            gsap.fromTo(
                juegosRef.current,
                { opacity: 0, scale: 0.8 },
                { opacity: 1, scale: 1, duration: 0.5, ease: "power2.out", stagger: 0.1 }
            );
        }
    }, [juegosAMostrar]);

    const [form, setForm] = useState({
        nombre: '',
        precioMenor: "",
        precioMayor: "",
    });

    const gestionarCambio = (e) => {
        const { name, value } = e.target;
        setForm({ ...form, [name]: value });
    };

    const validar = () => {
        const nuevosErrores = {};
        if (form.precioMenor !== "" && isNaN(Number(form.precioMenor))) {
            nuevosErrores.precioMenor = "El precio mínimo debe ser un número";
        }
        if (form.precioMayor !== "" && isNaN(Number(form.precioMayor))) {
            nuevosErrores.precioMayor = "El precio máximo debe ser un número";
        }
        if (form.precioMenor !== "" && Number(form.precioMenor) < 0) {
            nuevosErrores.precioMenor = "El precio mínimo no puede ser negativo";
        }
        if (form.precioMenor !== "" && form.precioMayor !== "" && Number(form.precioMenor) > Number(form.precioMayor)) {
            nuevosErrores.precioMenor = "El precio mínimo no puede ser mayor que el precio máximo";
        }
        setErrores(nuevosErrores);
        return Object.keys(nuevosErrores).length === 0;
    };

    const enviarFormulario = (e) => {
        e.preventDefault();
        if (validar()) {
            if (form.nombre.trim() !== "") {
                ServicioInformacion.getPorNombre(form.nombre)
                    .then((response) => {
                        setJuegosAMostrar(response.data);
                    })
                    .catch((error) => {
                        Swal.fire({
                            icon: "error",
                            title: "Oops...",
                            text: "No se ha podido descargar la información..."
                        });
                    });
            } else if (form.precioMenor.trim() !== "" || form.precioMayor.trim() !== "") {
                ServicioInformacion.getPorPrecio(form.precioMenor, form.precioMayor)
                    .then((response) => {
                        setJuegosAMostrar(response.data);
                    })
                    .catch((error) => {
                        Swal.fire({
                            icon: "error",
                            title: "Oops...",
                            text: "No se ha podido descargar la información..."
                        });
                    });
            } else {
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: "Por favor, complete al menos un campo para buscar."
                });
            }
        } else {
            Swal.fire({
                icon: "error",
                title: "Oops...",
                text: "Por favor, corrija los errores antes de continuar."
            });
        }
    };

    function limpiar() {
        setJuegosAMostrar(informacion);
        setForm({
            nombre: '',
            precioMenor: "",
            precioMayor: "",
        });
        setErrores({});
    }

    function annadirCarrito(juego) {
        const yaComprado = juegosComprados.find(j => j.id === juego.id);
        if (yaComprado) {
            Swal.fire({
                icon: "warning",
                title: "Ya tienes este juego",
                text: "Este juego ya está en tu biblioteca.",
            });
            return;
        }

        const enCarrito = juegosCarrito.find(j => j.id === juego.id);
        if (enCarrito) {
            Swal.fire({
                icon: "info",
                title: "Ya está en el carrito",
                text: "Este juego ya ha sido añadido al carrito.",
            });
            return;
        }

        setJuegosCarrito([...juegosCarrito, juego]);
        Swal.fire({
            icon: "success",
            title: "Añadido al carrito",
            text: `El juego "${juego.nombre}" ha sido añadido al carrito.`,
        });
    }

    return (
        <div className="tienda">
            <div className="cajaFormulario">
                <div className="formulario">
                    <form onSubmit={enviarFormulario}>
                        <label htmlFor="nombre">Nombre</label>
                        <input id="nombre" type="text" name="nombre" value={form.nombre} onChange={gestionarCambio} placeholder="Escribe el nombre del juego" />

                        <label htmlFor="precioMenor">Precio Mínimo</label>
                        <input id="precioMenor" type="text" name="precioMenor" value={form.precioMenor} onChange={gestionarCambio} placeholder="Importe Mínimo" />

                        <label htmlFor="precioMayor">Precio Máximo</label>
                        <input id="precioMayor" type="text" name="precioMayor" value={form.precioMayor} onChange={gestionarCambio} placeholder="Importe Máximo" />

                        <button type="submit">Buscar</button>
                        <button type="button" onClick={limpiar}>Limpiar</button>
                    </form>
                </div>
            </div>

            <div className="juegosMostrados">
                {Array.isArray(juegosAMostrar) && juegosAMostrar.length > 0 ? (
                    juegosAMostrar.map((item, index) => (
                        <div
                            key={item.id}
                            ref={(el) => (juegosRef.current[index] = el)}
                            className="juegoMostrado"
                        >
                            <p>{item.nombre}</p>
                            <img src={item.url} alt={item.nombre} />
                            <p>{item.precio}€</p>
                            <button className="annadirCarrito" onClick={() => annadirCarrito(item)}>Añadir al carrito</button>
                        </div>
                    ))
                ) : (
                    <p>No hay juegos disponibles.</p>
                )}
            </div>
        </div>
    );
};

export default Tienda;
