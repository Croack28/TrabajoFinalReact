import React from "react";
import ServicioInformacion from "../servicios/axios/ServicioInformacion";
import { useState } from "react";
import Swal from "sweetalert2";
import "../estilos/editarJuego.css";

const EditarJuego = ({ juego ,setInformacion,setJuegosComprados ,setJuegosCarrito,cerrarModalEditar}) => {

    const enviarFormulario = (e) => {
        e.preventDefault(); // Evita que el formulario se envíe automáticamente
      
        ServicioInformacion.editarElemento(juego.id,form)
                      .then((response) => {
                        
                        Swal.fire({
                            icon: "success",
                            title: "Juego editado",
                            text: "El juego ha sido editado correctamente."
                        });
        
                        // Actualiza el resto de listas
                        setInformacion((prevJuegos) =>
                            prevJuegos.map((juegoEditado) =>
                                juegoEditado.id === juego.id ? { ...juegoEditado, ...form } : juegoEditado
                            )
                        );

                        setJuegosComprados((prevJuegos) =>
                            prevJuegos.map((juegoEditado) =>
                                juegoEditado.id === juego.id ? { ...juegoEditado, ...form } : juegoEditado
                            )
                        );

                        setJuegosCarrito((prevJuegos) =>
                            prevJuegos.map((juegoEditado) =>
                                juegoEditado.id === juego.id ? { ...juegoEditado, ...form } : juegoEditado
                            )
                        );



                      })
                      .catch((error) => {
                        Swal.fire({
                          icon: "error",
                          title: "Oops...",
                          text: "No se ha podido eliminar el elemento..."
                        });
                        console.error(error); 
                      });

                      cerrarModalEditar()
   
    };

    const [form, setForm] = useState({
        nombre: juego.nombre,
        precio: Number(juego.precio),
        descripcion: juego.descripcion
    });

    const gestionarCambio = (e) => {
        const { name, value } = e.target;
    
        setForm({
            ...form,
            [name]: name === "precio" ? Number(value) : value, // Convertir solo si es "precio"
        });
    };
    


    return (
        <div className="editarForm">
            <form onSubmit={enviarFormulario}>
                {/* Campo de texto para nombre */}
                <label htmlFor="nombre">Nombre</label>
                <input
                    id="nombre"
                    type="text"
                    name="nombre"
                    value={form.nombre}
                    onChange={gestionarCambio}
                    placeholder="Escribe tu nombre"
                />

                {/* Campo de texto para apellidos */}
                <label htmlFor="precio">Precio</label>
                <input
                    id="precio"
                    type="text"
                    name="precio"
                    value={form.precio}
                    onChange={gestionarCambio}
                    placeholder="precio"
                />

                <label htmlFor="descripcion">Descripción</label>
                <textarea
                    id="descripcion"
                    name="descripcion"
                    value={form.descripcion}
                    onChange={gestionarCambio}
                    placeholder="Escribe la descripción aquí..."
                    rows="4" // Puedes ajustar la cantidad de filas visibles
                    className="textarea-descripcion"
                />



                <button type="submit">Editar</button>
            </form>
        </div>
    );
};

export default EditarJuego;