import React, { useState } from "react";
import "../estilos/menu.css";
import { Link } from "react-router-dom";

const MenuSuperior = ({ juegosCarrito,setJuegosCarrito}) => {
    const [carritoVisible, setCarritoVisible] = useState(false);

    const toggleCarrito = () => {
        setCarritoVisible(!carritoVisible);
    };

    const eliminarProducto = (id) => {
        const juegosFiltrados = juegosCarrito.filter(juego => juego.id !== id);
        setJuegosCarrito(juegosFiltrados);
    };

    return (
        <div className="barraSuperior">
            <div className="menuIzquierda">
                <div className="zonaLogo">
                    <img src="/imagenes/logo.png" className="logo" alt="Logo de PC Games" />
                    <p>PC Games</p>
                </div>
            </div>
            <div className="menuMedio">
                <ul className="linksMenu">
                    <li>
                        <Link to="/" className="link">TIENDA</Link>
                    </li>
                    <li>
                        <Link to="/biblioteca" className="link">BIBLIOTECA</Link>
                    </li>
                    <li>
                        <Link to="/admin" className="link">ADMIN</Link>
                    </li>
                </ul>
            </div>
            <div className="menuDerecha">
                <ul className="linksMenu">
                    <Link to="/detalleCarrito" className="link"><li className="link"><p>CARRITO</p></li></Link>
                    <li>
                        <button className="toggle-carrito" onClick={toggleCarrito}>
                            🛒
                        </button>
                    </li>
                </ul>
            </div>
            {carritoVisible && (
                <div className="carrito-productos">
                    <h4>Carrito</h4>
                    {juegosCarrito.length > 0 ? (
                        <ul className="lista-productos">
                            {juegosCarrito.map((producto, index) => (
                                <li key={index} className="producto-item">
                                    <span>{producto.nombre}</span>
                                    <button
                                        className="eliminar-producto"
                                        onClick={() => eliminarProducto(producto.id)}
                                    >
                                        🗑️
                                    </button>
                                </li>
                            ))}
                            <li>
                                <Link to="/detalleCarrito" className="annadirCarrito2">Ir al carrito</Link>
                            </li>
                        </ul>
                    ) : (
                        <p>No hay productos en el carrito.</p>
                    )}
                </div>
            )}
        </div>

    );
};

export default MenuSuperior;
