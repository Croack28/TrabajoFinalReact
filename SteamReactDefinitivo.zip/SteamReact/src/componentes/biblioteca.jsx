import React, { useState } from "react";
import "../estilos/biblioteca.css";
import Modal from "./Modal";
import DetalleJuego from "./detalleJuego";

const Biblioteca = ({ juegosComprados, informacion }) => {
    const [modalConsultarAbierto, setModalConsultarAbierto] = useState(false);
    const [productoSeleccionado, setProductoSeleccionado] = useState(null);
  
    const abrirModalConsultar = (juego) => {
      setProductoSeleccionado(juego);
      setModalConsultarAbierto(true);
    };
  
    return (
      <div className="contenedor-biblioteca">
        <div className="lista-juegos">
          <h2>Tu Biblioteca</h2>
          {juegosComprados.length === 0 ? (
            <p>No tienes juegos comprados.</p>
          ) : (
            juegosComprados.map((juego) => (
              <div
                key={juego.id}
                className="juego-biblioteca"
                onClick={() => abrirModalConsultar(juego)}
              >
                <img src={juego.url} alt={juego.nombre} className="juego-img" />
                <h3 className="juego-nombre">{juego.nombre}</h3>
              </div>
            ))
          )}
        </div>

        <Modal isOpen={modalConsultarAbierto} onClose={() => setModalConsultarAbierto(false)}>
          {productoSeleccionado && <DetalleJuego informacion={informacion} idJuego={productoSeleccionado.id} />}
        </Modal>
      </div>
    );
  };
  
  export default Biblioteca;
